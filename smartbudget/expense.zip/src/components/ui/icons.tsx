import { Rupee } from 'lucide-react';

// Replace
<DollarSign className="h-4 w-4" />
// With
<Rupee className="h-4 w-4" /> 