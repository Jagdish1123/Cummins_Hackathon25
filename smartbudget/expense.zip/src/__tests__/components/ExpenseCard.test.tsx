const mockExpense = {
  id: "1",
  amount: 3817.17, // Amount in INR
  category: "food",
  // ...
}; 